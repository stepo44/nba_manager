﻿using System;
using System.Collections.Generic;
using System.Text;

namespace nba
{
    class AllPlayers
    {
        public static Player[] players;  //dodać właściwość get;set

        public static void CreateAllPlayers()
        {
            players = new Player[15];

            Player Kevin_Durant = new Player("Kevin Durant", "Power Forward", 27.8, 7.2, 4.0, 1.2, 1.1, 53.2, 4.4, 9, 7.8, "Golden State Warriors", 32.3);
            players[0] = Kevin_Durant;
            Player James_Harden = new Player("James Harden", "Point Guard", 36.8, 6.2, 10.0, 1.4, 0.1, 53.2, 4.8, 10, 7.7, "Houston Rockets", 33.4);
            players[1] = James_Harden;
            Player Lebron_James = new Player("Lebron James", "Small Forward", 27.2, 8.2, 7.0, 0.8, 0.7, 53.2, 3.3, 10, 7.0, "Los Angeles Lakers", 35.0);
            players[2] = Lebron_James;
            Player Khawi_Leonard = new Player("Khawi Leonard", "Small Forward", 26.6, 7.8, 3.0, 2.8, 1.7, 53.2, 3.8, 8, 7.3, "Toronto Raptors", 23.1);
            players[3] = Khawi_Leonard;
            Player Nicola_Jokic = new Player("Nicola Jokic", "Center", 23.6, 10.8, 7.3, 0.3, 0.7, 53.2, 40.3, 9, 2.3, "Denver Nuggets", 12.1);
            players[4] = Nicola_Jokic;

            Player Krzysiek = new Player("Krzysiek", "Power Forward", 27.8, 7.2, 4.0, 1.2, 1.1, 53.2, 2.3, 9, 7.8, "Golden State Warriors", 32.3);
            players[5] = Krzysiek;
            Player Borowik = new Player("Borowik", "Shooting Guard", 36.8, 6.2, 10.0, 1.4, 0.1, 53.2, 1.9, 10, 7.7, "Houston Rockets", 33.4);
            players[6] = Borowik;
            Player Samojlik = new Player("Samojlik", "Small Forward", 27.2, 8.2, 7.0, 0.8, 0.7, 53.2, 4.9, 10, 7.0, "Los Angeles Lakers", 35.0);
            players[7] = Samojlik;
            Player Kungfu = new Player("Kungfu", "Shooting Guard", 26.6, 7.8, 3.0, 2.8, 1.7, 53.2, 1.7, 8, 7.3, "Toronto Raptors", 23.1);
            players[8] = Kungfu;
            Player Kozak = new Player("Kozak", "Center", 23.6, 10.8, 7.3, 0.3, 0.7, 53.2, 2.3, 9, 6.8, "Denver Nuggets", 12.1);
            players[9] = Kozak;

            Player Wasia = new Player("Wasia", "Power Forward", 27.8, 7.2, 4.0, 1.2, 1.1, 53.2, 1.3, 9, 7.8, "Golden State Warriors", 32.3);
            players[10] = Wasia;
            Player Iwan = new Player("Iwan", "Point Guard", 36.8, 6.2, 10.0, 1.4, 0.1, 53.2, 2.5, 10, 7.7, "Houston Rockets", 33.4);
            players[11] = Iwan;
            Player Wołodia = new Player("Wołodia", "Power Forward", 27.2, 8.2, 7.0, 0.8, 0.7, 53.2, 3.0, 10, 7.0, "Los Angeles Lakers", 35.0);
            players[12] = Wołodia;
            Player Ściopa = new Player("Ściopa", "Small Forward", 26.6, 7.8, 3.0, 2.8, 1.7, 53.2, 2.9, 8, 7.3, "Toronto Raptors", 23.1);
            players[13] = Ściopa;
            Player Wania = new Player("Wania", "Center", 23.6, 10.8, 7.3, 0.3, 0.7, 53.2, 2.5, 9, 6.8, "Denver Nuggets", 12.1);
            players[14] = Wania;
        }

        public static void PrintAllPlayers()
        {
            Console.WriteLine("       Pozostało:");
            foreach (var player in players)
            {
                if (player.availabilty == true)
                {
                    Console.WriteLine(player.name);
                }
            }
        }

        public static Player selectRandomPlayer()
        {
            // fun wywoływana i zwracająca obj Player do AllManagersChooseGuard1/Forward1...()

            List<Player> playersToRandomSelect = new List<Player>();

            for (int player = 0; player < AllPlayers.players.Length; player++)
            {
                if (players[player].availabilty == true)
                {
                    playersToRandomSelect.Add(players[player]);
                }
            }

            Random rand = new Random();
            int randIndex = rand.Next(playersToRandomSelect.Count);
            Player randPlayer = playersToRandomSelect[randIndex];
            return randPlayer;
        }
    }
}
