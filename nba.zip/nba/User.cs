﻿using System;
using System.Collections.Generic;
using System.Text;

namespace nba
{
    class User
    {
        public string name;
        public Team yourTeam;
        public string inputTeamNameValue;
        public static string inputPlayerNameValue;
        public bool availability = true;
        public static User[] managers;

        public static void CreateYourUser()
        {
            User you = new User();
            AllManagers.managers[0] = you;
            CreateName(you);
        }

        public static void CreateName(User you)
        {
            Console.WriteLine("Jak się nazywasz?");
            you.name = Console.ReadLine();
            Console.WriteLine("Nazywasz się " + you.name);
            Console.ReadLine();
            you.InputTeamName();
            //you.CheckInputTeamName();
        }

        public void InputTeamName()
        {
            AllTeams.PrintAllTeams();
            Console.WriteLine("Podaj nazwę swojej drużyny");
            inputTeamNameValue = Console.ReadLine();
            CheckInputTeamName();
        }

        public int CheckInputTeamName()
        {
            for (int i = 0; i < AllTeams.teams.Length; i++)
            {
                if (inputTeamNameValue == AllTeams.teams[i].name)
                {
                    yourTeam = AllTeams.teams[i]; // czy odwrotne przypisanie?
                    yourTeam.managerName = name;
                    AllTeams.teams[i].availability = false;
                    AllManagers.PopulateManagersArrayWithTheirTeams();
                    return 0;
                }
            }
            Console.WriteLine("Błąd w podanej nazwie");
            InputTeamName();
            return 0;
        }

        public static int ChooseGuard1()
        {
            Console.Write("\n Wybierz rozgrywającego:  ");
            inputPlayerNameValue = Console.ReadLine();
            foreach (var player in AllPlayers.players)
            {
                if (inputPlayerNameValue == player.name && player.availabilty == true)
                {
                    AllManagers.managers[0].yourTeam.guard1 = player;
                    player.availabilty = false;
                    return 0;
                }
            }
            Console.WriteLine("Błąd w nazwie");
            ChooseGuard1();
            return 0;
        }

        public static int ChooseGuard2()
        {
            Console.Write("\n Wybierz rzucającego obrońcę:  ");
            inputPlayerNameValue = Console.ReadLine();
            foreach (var player in AllPlayers.players)
            {
                if (inputPlayerNameValue == player.name && player.availabilty == true)
                {
                    AllManagers.managers[0].yourTeam.guard2 = player;
                    player.availabilty = false;
                    return 0;
                }
            }
            Console.WriteLine("Błąd w nazwie");
            ChooseGuard2();
            return 0;
        }

        public static int ChooseForward1()
        {
            Console.Write("\n Wybierz niskiego skrzydłowego:  ");
            inputPlayerNameValue = Console.ReadLine();
            foreach (var player in AllPlayers.players)
            {
                if (inputPlayerNameValue == player.name && player.availabilty == true)
                {
                    AllManagers.managers[0].yourTeam.forward1 = player;
                    player.availabilty = false;
                    return 0;
                }
            }
            Console.WriteLine("Błąd w nazwie");
            ChooseForward1();
            return 0;
        }

        public static int ChooseForward2()
        {
            Console.Write("\n Wybierz silnego skrzydłowego:  ");
            inputPlayerNameValue = Console.ReadLine();
            foreach (var player in AllPlayers.players)
            {
                if (inputPlayerNameValue == player.name && player.availabilty == true)
                {
                    AllManagers.managers[0].yourTeam.forward2 = player;
                    player.availabilty = false;
                    return 0;
                }
            }
            Console.WriteLine("Błąd w nazwie");
            ChooseForward2();
            return 0;
        }

        public static int ChooseCenter()
        {
            Console.Write("\n Wybierz centra:  \n");
            inputPlayerNameValue = Console.ReadLine();
            foreach (var player in AllPlayers.players)
            {
                if (inputPlayerNameValue == player.name && player.availabilty == true)
                {
                    AllManagers.managers[0].yourTeam.center = player;
                    player.availabilty = false;
                    return 0;
                }
            }
            Console.WriteLine("Błąd w nazwie");
            ChooseCenter();
            return 0;
        }

        public static void PrintYourRoster()
        {

            Console.WriteLine("PG = " + AllManagers.managers[0].yourTeam.guard1.name);
            Console.WriteLine("SG = " + AllManagers.managers[0].yourTeam.guard2.name);
            Console.WriteLine("SF = " + AllManagers.managers[0].yourTeam.forward1.name);
            Console.WriteLine("PF = " + AllManagers.managers[0].yourTeam.forward2.name);
            Console.WriteLine("C = " + AllManagers.managers[0].yourTeam.center.name);
        }
    }
}
