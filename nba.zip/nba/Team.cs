﻿using System;
using System.Collections.Generic;
using System.Text;

namespace nba
{
    class Team
    {
        public string name;
        public Player guard1;
        public Player guard2;
        public Player forward1;
        public Player forward2;
        public Player center;

        public string managerName;

        public bool availability = true;

        public double scorePositions;
        public double score3Points;
        public double scoreOffense;
        public double scoreDefense;
        public double scoreIQ;
        public double scoreTotal;


        public Team(string nameArg, Player guard1Arg, Player guard2Arg, Player forward1Arg, Player forward2Arg, Player centerArg, string managerNameArg)
        //kontruktor pełny
        {
            this.name = nameArg;
            this.guard1 = guard1Arg;
            this.guard2 = guard2Arg;
            this.forward1 = forward1Arg;
            this.forward2 = forward2Arg;
            this.center = centerArg;
            this.managerName = managerNameArg;
        }
        public Team(string nameArg, string managerNameArg) //konstruktor name
        {
            this.name = nameArg;
            this.managerName = managerNameArg;
        }

        public string getTeamName()
        {
            return name;
        }



    }
}
