﻿using System;

namespace nba
{
    class Program
    {
        static void Main(string[] args)
        {
            AllTeams allTeams = new AllTeams();

            AllTeams.CreateAllTeams();

            AllManagers.CreateManagersArray();

            User.CreateYourUser();

            AllManagers.PopulateManagersArrayWithTheirTeams();

            // pętla sprawdzająca managerów wszystkich drużyn
            //foreach (var team in AllTeams.teams)
            //{
            //    Console.WriteLine(team.name + "  " + team.managerName);
            //}

            AllPlayers.CreateAllPlayers();

            AllPlayers.PrintAllPlayers();

            User.ChooseGuard1();

            AllManagers.ManagersChooseGuard1();

            //CHECK POINT:
            //Console.WriteLine("Check guard1: ");
            //foreach (var manager in AllManagers.managers)
            //{
            //    Console.WriteLine(manager.name + " " + manager.yourTeam.name
            //                        + "  " + manager.yourTeam.guard1.name);   
            //}


            // IN WORK
            AllPlayers.PrintAllPlayers();

            User.ChooseGuard2();

            AllManagers.ManagersChooseGuard2();

            AllPlayers.PrintAllPlayers();

            User.ChooseForward1();

            AllManagers.ManagersChooseForward1();

            AllPlayers.PrintAllPlayers();

            User.ChooseForward2();

            AllManagers.ManagersChooseForward2();

            AllPlayers.PrintAllPlayers();

            User.ChooseCenter();

            AllManagers.ManagersChooseCenter();

            //CHECK POINT:
            Console.WriteLine("Rosters: ");
            foreach (var manager in AllManagers.managers)
            {
                Console.WriteLine(manager.name + " " + manager.yourTeam.name
                                    + "  " + manager.yourTeam.guard1.name + "  " + manager.yourTeam.guard2.name
                                    + "  " + manager.yourTeam.forward1.name + "  " + manager.yourTeam.forward2.name
                                    + "  " + manager.yourTeam.center.name + "\n");
            }

            //User.PrintYourRoster();
            //////////////////////////////////////////////////////////////////////////////////////
            

            Console.WriteLine("Zaczynamy algo");

            PositionsMatchUser.GetPositions();

            PositionsMatchUser.CheckIfIdealPositionMatch();

            Console.WriteLine("Wynik z pozycji to: " + AllManagers.managers[0].yourTeam.scorePositions);

            ScoreUser.GetPlayers();
            ScoreUser.CountScoreUser();

            PositionsMatchOtherManagers.CountPositionsScoreOtherManagers();
            ScoreOtherManagers.CountScoreOtherManagers();




            Console.Read();
        }
    }
}
